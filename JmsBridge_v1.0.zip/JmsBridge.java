import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Properties;
import java.io.InputStreamReader;

import javax.jms.Connection;
import javax.jms.DeliveryMode;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.jms.MessageProducer;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.jms.QueueReceiver;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.Session;
import javax.jms.TextMessage;
import javax.jms.Topic;
import javax.jms.TopicConnection;
import javax.jms.TopicConnectionFactory;
import javax.jms.TopicPublisher;
import javax.jms.TopicSession;
import javax.jms.TopicSubscriber;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class JmsBridge implements MessageListener {
	// Constants.
	private static final String OPTION_VERBOSE = "-verbose";
	private static final String OPTION_PROPS = "-props:";
	private static final String OPTION_SAVE = "-save:";
	private static final String OPTION_TEST = "-test:";
	private static final String OPTIN_USAGE1 = "-usage";
	private static final String OPTIN_USAGE2 = "-help";
	private static final String OPTIN_USAGE3 = "-?";

	private static final String DEFAULT_PROPERTIES_FILE_NAME = "/jmsbridge.properties";

	private static final String PRODUCER_INITIAL_CONTEXT_FACTORY = "producer." + Context.INITIAL_CONTEXT_FACTORY;
	private static final String PRODUCER_PROVIDER_URL = "producer." + Context.PROVIDER_URL;
	private static final String PRODUCER_URL_PKG_PREFIXES = "producer." + Context.URL_PKG_PREFIXES;
	private static final String PRODUCER_CONNECTION_FACTORY_NAME = "producer.jndi.connectionFactory.name";
	private static final String PRODUCER_DESTINATION_NAME = "producer.jndi.destination.name";
	private static final String PRODUCER_DESTINATION_TYPE = "producer.jndi.destination.type";
	private static final String PRODUCER_SELECTOR_NAME = "producer.jms.selector.name";
	private static final String PRODUCER_SELECTOR_VALUE = "producer.jms.selector.value";

	private static final String CONSUMER_INITIAL_CONTEXT_FACTORY = "consumer." + Context.INITIAL_CONTEXT_FACTORY;
	private static final String CONSUMER_PROVIDER_URL = "consumer." + Context.PROVIDER_URL;
	private static final String CONSUMER_URL_PKG_PREFIXES = "consumer." + Context.URL_PKG_PREFIXES;
	private static final String CONSUMER_CONNECTION_FACTORY_NAME = "consumer.jndi.connectionFactory.name";
	private static final String CONSUMER_DESTINATION_NAME = "consumer.jndi.destination.name";
	private static final String CONSUMER_DESTINATION_TYPE = "consumer.jndi.destination.type";
	private static final String CONSUMER_SELECTOR_NAME = "consumer.jms.selector.name";
	private static final String CONSUMER_SELECTOR_VALUE = "consumer.jms.selector.value";

	/**
	 * Properties.
	 */
	private Properties properties;

	/**
	 * Verbose flag.
	 */
	private boolean verbose;

	/**
	* Name of the file to save last seen message to.
	 */
	private String saveMessageFileName;

	/**
	 * Producer jms connection, hold on to this so you may close it.
	 */
	private Connection producerConnection;

	/**
	 * Producer jms session, hold on to this so you may close it. Also used to create messages.
	 */
	private Session producerSession;

	/**
	 * Consumer jms connection, hold on to this so you may close it.
	 */
	private Connection consumerConnection;

	/**
	 * Consumer jms session, hold on to this so you may close it. Also used to create messages.
	 */
	private Session consumerSession;

	/**
	 * Destination that consumer expects messages on.
	 */
	private MessageProducer consumerMessageSender;

	public static void main(String[] args) {
		boolean runVerbose = false;
		String props = DEFAULT_PROPERTIES_FILE_NAME;
		String saveFile = null;
		String testFile = null;
		for (int i = 0; i < args.length; i++) {
			if (args[i].startsWith(OPTION_PROPS)) {
				try {
					props = args[i].substring(OPTION_PROPS.length());
				}
				catch (Exception e) {
					System.out.println("Invalid properties file name.");
					printUsage();
					System.exit(0);
				}
			}
			else if (args[i].startsWith(OPTION_SAVE)) {
				try {
					saveFile = args[i].substring(OPTION_SAVE.length());
				}
				catch (Exception e) {
					System.out.println("Invalid save message file name.");
					printUsage();
					System.exit(0);
				}
			}
			else if (args[i].startsWith(OPTION_TEST)) {
				try {
					testFile = args[i].substring(OPTION_TEST.length());
				}
				catch (Exception e) {
					System.out.println("Invalid test message file name.");
					printUsage();
					System.exit(0);
				}
			}
			else if (args[i].equals(OPTION_VERBOSE)) {
				runVerbose = true;
			}
			else if (args[i].equals(OPTIN_USAGE1) || args[i].equalsIgnoreCase(OPTIN_USAGE2) || args[i].equalsIgnoreCase(OPTIN_USAGE3)) {
				printUsage();
				System.exit(0);
			}
		}

		try {
			final JmsBridge bridge = new JmsBridge(props, saveFile, runVerbose);
			if (testFile != null ) {
				File testMessageFile = new File(testFile);
				if (testMessageFile.exists()) {
					char[] buffer = new char[(int) testMessageFile.length()];
					FileReader fileReader = new FileReader(testMessageFile);
					int read = fileReader.read(buffer);
					String text = new String(buffer, 0, read);
					fileReader.close();
					bridge.initializeConsumer();
					bridge.sendToConsumer(text);
					bridge.close();
					System.exit(0);
				}
				else {
					System.out.println("Could not find test message file " + testFile + ".");
					System.exit(0);
				}
			}
			else {

				Runtime.getRuntime().addShutdownHook(new Thread() {
					public void run() {
						try {
							bridge.close();
						}
						catch (Exception e) {
						}
					}
				});

				bridge.initializeProducer();
				if (saveFile == null || saveFile.length() == 0) {
					bridge.initializeConsumer();
				}

				bridge.start();
				bridge.close();

//				Thread.currentThread().sleep(Long.MAX_VALUE);
			}
		}
		catch (Exception e) {
			if (runVerbose) {
				e.printStackTrace();
			}
		}
	}

	public static void printUsage() {
		System.out.println("Usage:");
		System.out.println("   JmsBridge [-props:<properties_file>] [-save:<save_message_file>]");
		System.out.println("             [-test:<test_message_file>] [-verbose] [-help|-usage|-?]");
		System.out.println("\n\t -props:<properties_file>");
		System.out.println("\t\t Allows to specify the properties file name that contains jndi ");
		System.out.println("\t\t information about producer and consumer to set the jms bridge");
		System.out.println("\t\t between. If <properties_file> is not specified, this program");
		System.out.println("\t\t attempts to find and use '" + DEFAULT_PROPERTIES_FILE_NAME + "' on the root");
		System.out.println("\t\t of classpath.");
		System.out.println("\n\t -save:<save_message_file>");
		System.out.println("\t\t Indicates that incoming message should be just saved to a file");
		System.out.println("\t\t without being redirected to consumer. <save_message_file>");
		System.out.println("\t\t allows to specify the name of the file where the last incoming");
		System.out.println("\t\t message is be saved to. (Incoming messages do not get appended");
		System.out.println("\t\t to the save file so it contains the last received message only.");
		System.out.println("\n\t -test:<test_message_file>");
		System.out.println("\t\t Initializes connection to consumer only and sends a test text");
		System.out.println("\t\t message to it. The test message text is obtained from a file");
		System.out.println("\t\t specified by <test_message_file>.");
		System.out.println("\n\t -verbose");
		System.out.println("\t\t Runs in vervose mode (prints extra info on exceptions).");
		System.out.println("\n\t -help|-usage|-?");
		System.out.println("\t\t Outputs this usage information.");
		System.out.println("\nExample:");
		System.out.println("\t JmsBridge -props:bridge.properties");
		System.out.println("\t JmsBridge -props:bridge.properties -save:message.txt -verbose");
		System.out.println("\t JmsBridge -props:bridge.properties -test:TestMessage.txt");
		System.exit(0);

	}

	public JmsBridge(String aPropertiesFileName, String aSaveMessageFileName, boolean aVerbose) throws Exception {
		verbose = aVerbose;
		saveMessageFileName = aSaveMessageFileName;
		properties = new Properties();
		System.out.print("Loading properties file: " + aPropertiesFileName + " ... ");
		properties.load(getClass().getResourceAsStream(aPropertiesFileName));
		System.out.println("OK.");
	}

	public void initializeProducer() throws Exception {
		String contextFactory = properties.getProperty(PRODUCER_INITIAL_CONTEXT_FACTORY);
		String providerUrl = properties.getProperty(PRODUCER_PROVIDER_URL);
		String urlPkg = properties.getProperty(PRODUCER_URL_PKG_PREFIXES);
		String connectionFactoryName = properties.getProperty(PRODUCER_CONNECTION_FACTORY_NAME);
		String destinationName = properties.getProperty(PRODUCER_DESTINATION_NAME);
		String destinationType = properties.getProperty(PRODUCER_DESTINATION_TYPE);

		if (contextFactory == null || contextFactory.length() == 0) {
			throw new Exception("No producer initial context factory is specified [property " + PRODUCER_INITIAL_CONTEXT_FACTORY + "].");
		}

		if (providerUrl == null || providerUrl.length() == 0) {
			throw new Exception("No producer provider url is specified [property " + PRODUCER_PROVIDER_URL + "].");
		}

		if (connectionFactoryName == null || connectionFactoryName.length() == 0) {
			throw new Exception("No producer connection factory name is specified [property " + PRODUCER_CONNECTION_FACTORY_NAME + "].");
		}

		if (destinationName == null || destinationName.length() == 0) {
			throw new Exception("No producer destination name is specified [property " + PRODUCER_DESTINATION_NAME + "].");
		}

		if (destinationType == null || destinationType.length() == 0) {
			throw new Exception("No producer destination type is specified [property " + PRODUCER_DESTINATION_TYPE + "].");
		}
		else {
			destinationType = destinationType.toUpperCase();
			if (!destinationType.equals("TOPIC") && !destinationType.equals("QUEUE")) {
				throw new Exception("Invalid producer destination type is specified [property " + PRODUCER_DESTINATION_TYPE + "], valid values are 'topic' or 'queue'.");
			}
		}

		System.out.print("Connecting to producer JNDI ... ");
		Properties environment = new Properties();
		environment.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
		environment.put(Context.PROVIDER_URL, providerUrl);
		environment.put(Context.URL_PKG_PREFIXES, urlPkg);
		Context context = new InitialContext(environment);
		System.out.println("OK.");

		if (destinationType.equals("TOPIC")) {
			System.out.print("Looking up producer topic factory: " + connectionFactoryName + " ... ");
			TopicConnectionFactory topicFactory = (TopicConnectionFactory) PortableRemoteObject.narrow(context.lookup(connectionFactoryName), TopicConnectionFactory.class);
			System.out.println("OK.");
			System.out.print("Looking up producer topic: " + destinationName + " ... ");
			Topic topic = (Topic) PortableRemoteObject.narrow(context.lookup(destinationName), Topic.class);
			System.out.println("OK.");

			producerConnection = topicFactory.createTopicConnection();
			producerSession = ((TopicConnection) producerConnection).createTopicSession(false, producerSession.AUTO_ACKNOWLEDGE);
			TopicSubscriber topicSubscriber = null;
			if (properties.getProperty (PRODUCER_SELECTOR_NAME) != null)
			{
				topicSubscriber = ((TopicSession)producerSession).createSubscriber(topic, properties.getProperty(PRODUCER_SELECTOR_NAME)+"='"+properties.getProperty(PRODUCER_SELECTOR_VALUE)+"'", false);
				System.out.println ("Subscribed to Topic Queue "+ destinationName + " with Selector: " + properties.getProperty(PRODUCER_SELECTOR_NAME)+ "='" + properties.getProperty(PRODUCER_SELECTOR_VALUE) + "'");
			}
			else
			{
				topicSubscriber = ((TopicSession) producerSession).createSubscriber(topic);
				System.out.println ("Subscribed to Topic Queue " + destinationName);
			}
			topicSubscriber.setMessageListener(this);
		}
		else {
			System.out.print("Looking up producer queue factory: " + connectionFactoryName + " ... ");
			QueueConnectionFactory queueFactory = (QueueConnectionFactory) PortableRemoteObject.narrow(context.lookup(connectionFactoryName), QueueConnectionFactory.class);
			System.out.println("OK.");
			System.out.print("Looking up producer queue: " + destinationName + " ... ");
			Queue queue = (Queue) PortableRemoteObject.narrow(context.lookup(destinationName), Queue.class);
			System.out.println("OK.");

			producerConnection = queueFactory.createQueueConnection();
			producerSession = ((QueueConnection) producerConnection).createQueueSession(false, producerSession.AUTO_ACKNOWLEDGE);
			QueueReceiver queueReceiver = null;
			if (properties.getProperty (PRODUCER_SELECTOR_NAME) != null)
			{
				queueReceiver = ((QueueSession) producerSession).createReceiver(queue, properties.getProperty(PRODUCER_SELECTOR_NAME)+"='"+properties.getProperty(PRODUCER_SELECTOR_VALUE)+"'");
				System.out.println ("Receiver Created for Queue" + destinationName + " with Selector: " + properties.getProperty(PRODUCER_SELECTOR_NAME) + "='" + properties.getProperty(PRODUCER_SELECTOR_VALUE) + "'");
			}
			else
			{
				queueReceiver = ((QueueSession) producerSession).createReceiver(queue);
				System.out.println ("Receiver Created for Queue " + destinationName);
			}
			queueReceiver.setMessageListener(this);
		}
	}

	public void initializeConsumer() throws Exception {
		String contextFactory = properties.getProperty(CONSUMER_INITIAL_CONTEXT_FACTORY);
		String providerUrl = properties.getProperty(CONSUMER_PROVIDER_URL);
		String urlPkg = properties.getProperty(CONSUMER_URL_PKG_PREFIXES);
		String connectionFactoryName = properties.getProperty(CONSUMER_CONNECTION_FACTORY_NAME);
		String destinationName = properties.getProperty(CONSUMER_DESTINATION_NAME);
		String destinationType = properties.getProperty(CONSUMER_DESTINATION_TYPE);

		if (contextFactory == null || contextFactory.length() == 0) {
			throw new Exception("No consumer initial context factory is specified [property " + PRODUCER_INITIAL_CONTEXT_FACTORY + "].");
		}

		if (providerUrl == null || providerUrl.length() == 0) {
			throw new Exception("No consumer provider url is specified [property " + CONSUMER_PROVIDER_URL + "].");
		}

		if (connectionFactoryName == null || connectionFactoryName.length() == 0) {
			throw new Exception("No consumer connection factory name is specified [property " + CONSUMER_CONNECTION_FACTORY_NAME + "].");
		}

		if (destinationName == null || destinationName.length() == 0) {
			throw new Exception("No consumer destination name is specified [property " + CONSUMER_DESTINATION_NAME + "].");
		}

		if (destinationType == null || destinationType.length() == 0) {
			throw new Exception("No consumer destination type is specified [property " + CONSUMER_DESTINATION_TYPE + "].");
		}
		else {
			destinationType = destinationType.toUpperCase();
			if (!destinationType.equals("TOPIC") && !destinationType.equals("QUEUE")) {
				throw new Exception("Invalid consumer destination type is specified [property " + CONSUMER_DESTINATION_TYPE + "], valid values are 'topic' or 'queue'.");
			}
		}

		System.out.print("Connecting to consumer JNDI ... ");
		Properties environment = new Properties();
		environment.put(Context.INITIAL_CONTEXT_FACTORY, contextFactory);
		environment.put(Context.PROVIDER_URL, providerUrl);
		environment.put(Context.URL_PKG_PREFIXES, urlPkg);
		Context context = new InitialContext(environment);
		System.out.println("OK.");

		if (destinationType.equals("TOPIC")) {
			System.out.print("Looking up consumer topic factory: " + connectionFactoryName + " ... ");
			TopicConnectionFactory topicFactory = (TopicConnectionFactory) PortableRemoteObject.narrow(context.lookup(connectionFactoryName), TopicConnectionFactory.class);
			System.out.println("OK.");
			System.out.print("Looking up consumer topic: " + destinationName + " ... ");
			Topic topic = (Topic) PortableRemoteObject.narrow(context.lookup(destinationName), Topic.class);
			System.out.println("OK.");

			consumerConnection = topicFactory.createTopicConnection();
			consumerSession = ((TopicConnection) consumerConnection).createTopicSession(false, consumerSession.AUTO_ACKNOWLEDGE);
			consumerMessageSender = ((TopicSession) consumerSession).createPublisher(topic);
		}
		else {
			System.out.print("Looking up consumer queue factory: " + connectionFactoryName + " ... ");
			QueueConnectionFactory queueFactory = (QueueConnectionFactory) PortableRemoteObject.narrow(context.lookup(connectionFactoryName), QueueConnectionFactory.class);
			System.out.println("OK.");
			System.out.print("Looking up consumer queue: " + destinationName + " ... ");
			Queue queue = (Queue) PortableRemoteObject.narrow(context.lookup(destinationName), Queue.class);
			System.out.println("OK.");

			consumerConnection = queueFactory.createQueueConnection();
			consumerSession = ((QueueConnection) consumerConnection).createQueueSession(false, consumerSession.AUTO_ACKNOWLEDGE);
			consumerMessageSender = ((QueueSession) consumerSession).createSender(queue);
		}
	}

	public void start() throws JMSException {
		producerConnection.start();
		System.out.println("Listening ...");
		try {
		waitForQuitKey();
		} catch (Exception e) {}
	}

	// wait for 'q' or 'Q' to terminate the program
	private void waitForQuitKey() throws Exception {
	    System.out.println( "Q or q to end..." );
	    char answer = 'x';
	    InputStreamReader inputStreamReader = new InputStreamReader( System.in );
	    while( !( ( answer == 'q' ) || ( answer == 'Q' ) ) ) {
	      answer = (char) inputStreamReader.read();
	    }
	}


	public void close() throws JMSException {
		if (producerSession != null) {
			producerSession.close();
		}

		if (producerConnection != null) {
			producerConnection.close();
		}

		if (consumerMessageSender != null) {
			consumerMessageSender.close();
		}

		if (consumerSession != null) {
			consumerSession.close();
		}

		if (consumerConnection != null) {
			consumerConnection.close();
		}
	}

	public void onMessage(Message aMessage) {
		try {
			if (aMessage instanceof TextMessage) {
				System.out.println("####################");
				System.out.println("# Incoming message #");
				System.out.println("####################");
				String text = ((TextMessage) aMessage).getText();
				System.out.println(text);
				sendToConsumer(text);
				System.out.println("\n\n");

				if (saveMessageFileName != null && saveMessageFileName.length() > 0) {
					FileWriter fileWriter = null;
					try {
						fileWriter = new FileWriter(saveMessageFileName);
						fileWriter.write(text);
					}
					catch (IOException e) {
						System.out.println("Failed to save incoming message to file.");
						if (verbose) {
							e.printStackTrace();
						}
					}
					finally {
						if (fileWriter != null) {
							try {
								fileWriter.close();
							}
							catch (IOException e) {
							}
						}
					}
				}
			}
			else {
				System.out.println("JMS Subscriber got a non-text message");
			}
		}
		catch (JMSException e) {
			System.err.println("Could not process text message: " + e.getMessage());
			if (verbose) {
				e.printStackTrace();
			}
		}
	}

	public void sendToConsumer(String aText) {
		if (consumerConnection != null && consumerSession != null && consumerMessageSender != null) {
			System.out.print("Sending message to consumer ... ");
			try {
				TextMessage message = consumerSession.createTextMessage();
				message.setText(aText);
				if (properties.getProperty (CONSUMER_SELECTOR_NAME) != null)
					message.setStringProperty (properties.getProperty(CONSUMER_SELECTOR_NAME), properties.getProperty (CONSUMER_SELECTOR_VALUE));

				if (consumerMessageSender instanceof TopicPublisher) {
					((TopicPublisher) consumerMessageSender).publish(message, DeliveryMode.PERSISTENT, Message.DEFAULT_PRIORITY, Message.DEFAULT_TIME_TO_LIVE);
				}
				else {
					((QueueSender) consumerMessageSender).send(message, DeliveryMode.PERSISTENT, Message.DEFAULT_PRIORITY, Message.DEFAULT_TIME_TO_LIVE);
				}
				System.out.println("OK.");
			}
			catch (JMSException e) {
				System.out.println("Failed to redirect message to consumer: " + e.getMessage());
				if (verbose) {
					e.printStackTrace();
				}
			}
		}
	}
}
